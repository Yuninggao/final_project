package com.mmall.service;

import com.mmall.entity.UserAddress;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Yuning
 * @since 2023-11-07
 */
public interface UserAddressService extends IService<UserAddress> {

}
