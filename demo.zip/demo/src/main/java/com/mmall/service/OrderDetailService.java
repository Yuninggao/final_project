package com.mmall.service;

import com.mmall.entity.OrderDetail;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Yuning
 * @since 2023-11-07
 */
public interface OrderDetailService extends IService<OrderDetail> {

}
