package com.mmall.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Yuning
 * @since 2023-11-07
 */
@Controller
@RequestMapping("//orderDetail")
public class OrderDetailController {

}

